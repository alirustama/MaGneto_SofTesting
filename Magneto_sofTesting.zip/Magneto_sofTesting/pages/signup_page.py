from selenium.webdriver.common.by import By

class SignupPage:
    def save_screenshot(self, filename="result_screenshot.png"):
        self.driver.save_screenshot(filename)
    def __init__(self, driver):
        self.driver = driver
        self.first_name_input = (By.ID, "firstname")
        self.last_name_input = (By.ID, "lastname")
        self.email_input = (By.ID, "email_address")
        self.password_input = (By.ID, "password")
        self.confirm_password_input = (By.ID, "password-confirmation")
        self.create_account_button = (By.XPATH, "//button[@title='Create an Account']")
        self.success_message = (By.CSS_SELECTOR, "div.message-success")

    def open(self):
        self.driver.get("https://magento.softwaretestingboard.com/customer/account/create/")
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        WebDriverWait(self.driver, 5).until(
            EC.presence_of_element_located(self.first_name_input)
        )

    def enter_first_name(self, first_name):
        self.driver.find_element(*self.first_name_input).clear()
        self.driver.find_element(*self.first_name_input).send_keys(first_name)

    def enter_last_name(self, last_name):
        self.driver.find_element(*self.last_name_input).clear()
        self.driver.find_element(*self.last_name_input).send_keys(last_name)

    def enter_email(self, email):
        self.driver.find_element(*self.email_input).clear()
        self.driver.find_element(*self.email_input).send_keys(email)

    def enter_password(self, password):
        self.driver.find_element(*self.password_input).clear()
        self.driver.find_element(*self.password_input).send_keys(password)

    def enter_confirm_password(self, password):
        self.driver.find_element(*self.confirm_password_input).clear()
        self.driver.find_element(*self.confirm_password_input).send_keys(password)

    def submit(self):
        self.driver.find_element(*self.create_account_button).click()

    def get_success_message(self, screenshot_path=None):
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        element = WebDriverWait(self.driver, 7).until(
            EC.visibility_of_element_located(self.success_message)
        )
        if screenshot_path:
            self.save_screenshot(screenshot_path)
        return element.text
