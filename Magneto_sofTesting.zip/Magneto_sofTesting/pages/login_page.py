from selenium.webdriver.common.by import By

class LoginPage:
    def save_screenshot(self, filename="login_screenshot.png"):
        self.driver.save_screenshot(filename)
    def __init__(self, driver):
        self.driver = driver
        self.email_input = (By.ID, "email")
        self.password_input = (By.ID, "pass")
        self.signin_button = (By.ID, "send2")
        self.welcome_message = (By.CSS_SELECTOR, "div.panel.header span.logged-in")

    def open(self):
        self.driver.get("https://magento.softwaretestingboard.com/customer/account/login/")

    def enter_email(self, email):
        self.driver.find_element(*self.email_input).clear()
        self.driver.find_element(*self.email_input).send_keys(email)

    def enter_password(self, password):
        self.driver.find_element(*self.password_input).clear()
        self.driver.find_element(*self.password_input).send_keys(password)

    def submit(self):
        self.driver.find_element(*self.signin_button).click()

    def get_welcome_message(self, screenshot_path=None):
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        element = WebDriverWait(self.driver, 7).until(
            EC.visibility_of_element_located(self.welcome_message)
        )
        if screenshot_path:
            self.save_screenshot(screenshot_path)
        return element.text
