import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from selenium import webdriver
from pages.signup_page import SignupPage
from pages.login_page import LoginPage
import random

def generate_account():
    rand = random.randint(1000,9999)
    first_name = 'Rustam'
    last_name = 'Tester'
    email = f'rustam.tester{rand}@example.com'
    password = '123@Password'
    return {'first_name': first_name, 'last_name': last_name, 'email': email, 'password': password}

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    yield driver
    driver.quit()

@pytest.fixture(scope="module")
def account():
    return generate_account()

def test_signup_and_signin(driver, account):
    # Sign up
    signup_page = SignupPage(driver)
    signup_page.open()
    signup_page.enter_first_name(account['first_name'])
    signup_page.enter_last_name(account['last_name'])
    signup_page.enter_email(account['email'])
    signup_page.enter_password(account['password'])
    signup_page.enter_confirm_password(account['password'])
    signup_page.submit()
    screenshot_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    if not os.path.exists(screenshot_dir):
        os.makedirs(screenshot_dir)
    signup_screenshot = os.path.join(screenshot_dir, 'signup_and_signin_signup.png')
    assert "Thank you for registering" in signup_page.get_success_message(screenshot_path=signup_screenshot)

    # Sign out (optional, if needed)
    driver.get("https://magento.softwaretestingboard.com/customer/account/logout/")

    # Sign in
    login_page = LoginPage(driver)
    login_page.open()
    login_page.enter_email(account['email'])
    login_page.enter_password(account['password'])
    login_page.submit()
    signin_screenshot = os.path.join(screenshot_dir, 'signup_and_signin_signin.png')
    welcome_text = login_page.get_welcome_message(screenshot_path=signin_screenshot)
    assert account['first_name'] in welcome_text or account['email'] in welcome_text
