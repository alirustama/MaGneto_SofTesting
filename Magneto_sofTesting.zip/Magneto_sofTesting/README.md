# Magento Account Automation

This project automates the process of creating an account and signing in on [Magento Demo](https://magento.softwaretestingboard.com/) using Selenium, Pytest, and Page Object Model (POM).

## Features
- Automated sign-up and sign-in with a single test flow
- Screenshots saved for both sign-up and sign-in steps in the `results` folder
- Clean project structure using POM and fixtures

## Setup
1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Download ChromeDriver:**
   - Ensure ChromeDriver is installed and in your PATH.
   - [Download ChromeDriver](https://chromedriver.chromium.org/downloads)

3. **Run the test:**
   ```bash
   python run_tests.py
   ```
   or
   ```bash
   pytest --html=report.html tests/test_account_flow.py
   ```

## Project Structure
```
Magneto_sofTesting/
├── pages/
│   ├── signup_page.py
│   └── login_page.py
├── tests/
│   └── test_account_flow.py
├── results/
│   ├── signup_screenshot.png
│   └── signin_screenshot.png
├── requirements.txt
├── run_tests.py
└── README.md
```

## Output
- Screenshots for sign-up and sign-in are saved in the `results` folder.
- An HTML report is generated as `report.html`.

## Notes
- The test generates a unique email for each run to avoid duplicate accounts.
- Only one test file is maintained for clarity and reliability.

## Troubleshooting
- Ensure ChromeDriver matches your installed Chrome version.
- If you encounter element not found errors, check for site changes or slow network.

---
**Author:** Automation by GitHub Copilot
